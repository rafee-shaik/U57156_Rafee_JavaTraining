package com.b1;

import java.util.*;

public class HashMapEg {
	public static void main(String[] args) {
		
		HashMap<String, String> hmap= new HashMap<>();
		
		hmap.put("name31", "msg31");
		hmap.put("name21", "msg21");
		hmap.put("name11", "msg11");
		hmap.put("name41", "msg41");
		
		Set<String> ss = hmap.keySet();
		
	for (String key_item : ss) {
		System.out.println(key_item +"------>"+ hmap.get(key_item));
		
	}
	
	}
	

}