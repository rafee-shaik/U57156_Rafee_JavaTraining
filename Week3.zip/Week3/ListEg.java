package com.a2;

import java.util.*;



class City{
	
	private String name;
	private long pincode;
	private String cap_city;
	
	//Constructor
	public City(String name, long pincode, String cap_city) {
		super();
		this.name = name;
		this.pincode = pincode;
		this.cap_city = cap_city;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	public String getCap_city() {
		return cap_city;
	}
	public void setCap_city(String cap_city) {
		this.cap_city = cap_city;
	}
	
	//toString
	@Override
	public String toString() {
		return "City [name=" + name + ", pincode=" + pincode + ", cap_city=" + cap_city + "]";
	}
	
	
	
	
	
}


public class ListEg {

	public static void main(String[] args) {
		// Create LIst
		

		
		List<City> cities = new ArrayList<City>();
		
		Scanner scnr = new Scanner(System.in);
		
		// Add city objects to list
		
		cities.add(new City("city1", 1234, "capital1" ));
		cities.add(new City("city2", 2234, "capital2" ));
		cities.add(new City("city3", 3234, "capital3" ));
		
		System.out.println("Please enter the city name");
		String city = scnr.next();
		
		System.out.println("Please enter the pin code");
		
		
		
		
		//iteration and display
		
		Iterator<City> itr = cities.iterator();
		
		while (itr.hasNext()){
			
			System.out.println(itr.next());
		}
		
	

	}

}
