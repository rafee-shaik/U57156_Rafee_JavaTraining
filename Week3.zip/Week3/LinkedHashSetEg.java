package com.b1;

import java.util.LinkedHashSet;

public class LinkedHashSetEg {

	public static void main(String[] args) {
		LinkedHashSet<String> lhs= new LinkedHashSet<String>();
		lhs.add("aaaa");
		lhs.add("bbbbbb");
		lhs.add("aaaa");
		lhs.add("ccccc");
		
		lhs.stream().forEach((item)->{System.out.println(item);});
	}
}