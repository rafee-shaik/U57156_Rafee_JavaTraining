package com.b1;

public class ExceptionEg {
	public static void main(String[] args) {
		
		String str= "abcd";
		int val= Integer.parseInt(str);
		val*=1.1;
		
		System.out.println(val);
	}

}