package com.a3;

import java.util.*;

class Country{
	
	private String name;
	private double gdp;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getGdp() {
		return gdp;
	}
	public void setGdp(double gdp) {
		this.gdp = gdp;
	}
	public Country(String name, double gdp) {
		super();
		this.name = name;
		this.gdp = gdp;
	}
	
	
}

public class TreesetEg {

	public static void main(String[] args) {
		
		TreeSet<String> tss = new TreeSet<String>(new Mycomparator());
		
		tss.add("AAAAAAAAAAAA");
		tss.add("C");
		tss.add("CCCCCCCCC");
		tss.add("C");
		tss.add("BBBBBBBBBB");
		tss.add("CCCCCCCCC");
		tss.add("BBBBBBBBBB");
		tss.addAll(tss);
		
		for (String element : tss) {
			System.out.print(element+ "\t");
		}
		
		
		Iterator<String> itrs = tss.iterator();
		
		for(; itrs.hasNext();) {
			System.out.println("\n"+itrs.next());
		}
		
		

	}

}

class Mycomparator implements Comparator<String>{

	@Override
	public int compare(String str1, String str2) {
		
		return str1.compareTo(str2);
	}
	
}
