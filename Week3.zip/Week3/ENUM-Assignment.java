package com.b1;

enum Day {
		MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
	};
	
public class EnumEg {

	Day day = Day.FRIDAY;
	
	public static void main(String[] args) {

		Day today = Day.FRIDAY;
		printWeekend(today);
	}
	
	
	
	static public void printWeekend(Day today) {
		if (today == Day.SATURDAY) {
			
			System.out.println("It's Weekend, Saturday");
			
		} else if (today == Day.SUNDAY) {
			
			System.out.println("It's Weekend, Sunday");
			
		} else {
			
			System.out.println("It's not Weekend");
		}
		
		switch(today) {
		
		case MONDAY:
			System.out.println("Today is MONDAY");
			break;
		case TUESDAY:
			System.out.println("Today is TUESDAY");
			break;
		case WEDNESDAY:
			System.out.println("Today is WEDNESDAY");
			break;
		default:
			System.out.println("Its not MONDAY, TUESDAY, WEDNESDAY");
		}
		
	}

	
	Day getSunday() {
		return Day.SUNDAY;
	}
}